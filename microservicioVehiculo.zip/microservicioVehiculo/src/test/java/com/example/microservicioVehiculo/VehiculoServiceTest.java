package com.example.microservicioVehiculo;

import com.example.microservicioVehiculo.model.Vehiculo;
import com.example.microservicioVehiculo.repository.VehiculoRepository;
import com.example.microservicioVehiculo.service.VehiculoService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class VehiculoServiceTest {

    @Mock
    private VehiculoRepository repository;

    @InjectMocks
    private VehiculoService service;

    private Vehiculo vehiculo;

    @BeforeEach
    void setUp() {
        vehiculo = new Vehiculo();
        vehiculo.setId(1L);
        vehiculo.setMarca("Toyota");
        vehiculo.setModelo("Corolla");
        vehiculo.setAnio(2024);
        vehiculo.setPrecio(20000000.0);
        vehiculo.setStock(5);
    }

    @Test
    void crearDebeGuardarVehiculo() {

        when(repository.save(any(Vehiculo.class)))
                .thenReturn(vehiculo);

        Vehiculo resultado = service.crear(vehiculo);

        assertEquals("DISPONIBLE", resultado.getEstado());
        verify(repository).save(vehiculo);
    }

    @Test
    void crearDebeLanzarExcepcionSiStockEsNegativo() {

        vehiculo.setStock(-1);

        RuntimeException ex = assertThrows(
                RuntimeException.class,
                () -> service.crear(vehiculo)
        );

        assertEquals("Stock no puede ser negativo", ex.getMessage());

        verify(repository, never()).save(any());
    }

    @Test
    void listarDebeRetornarLista() {

        when(repository.findAll())
                .thenReturn(List.of(vehiculo));

        List<Vehiculo> lista = service.listar();

        assertEquals(1, lista.size());
        verify(repository).findAll();
    }

    @Test
    void obtenerDebeRetornarVehiculo() {

        when(repository.findById(1L))
                .thenReturn(Optional.of(vehiculo));

        Vehiculo resultado = service.obtener(1L);

        assertEquals("Toyota", resultado.getMarca());
    }

    @Test
    void obtenerDebeLanzarExcepcionSiNoExiste() {

        when(repository.findById(1L))
                .thenReturn(Optional.empty());

        assertThrows(
                RuntimeException.class,
                () -> service.obtener(1L)
        );
    }

    @Test
    void actualizarDebeModificarDatos() {

        Vehiculo nuevo = new Vehiculo();
        nuevo.setMarca("Honda");
        nuevo.setModelo("Civic");
        nuevo.setAnio(2025);
        nuevo.setPrecio(25000000.0);
        nuevo.setStock(10);

        when(repository.findById(1L))
                .thenReturn(Optional.of(vehiculo));

        when(repository.save(any(Vehiculo.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        Vehiculo actualizado = service.actualizar(1L, nuevo);

        assertEquals("Honda", actualizado.getMarca());
        assertEquals("Civic", actualizado.getModelo());
        assertEquals(10, actualizado.getStock());

        verify(repository).save(any(Vehiculo.class));
    }

    @Test
    void eliminarDebeLlamarDeleteById() {

        service.eliminar(1L);

        verify(repository).deleteById(1L);
    }

    @Test
    void reducirStockDebeDisminuirEnUno() {

        when(repository.findById(1L))
                .thenReturn(Optional.of(vehiculo));

        when(repository.save(any(Vehiculo.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        Vehiculo resultado = service.reducirStock(1L);

        assertEquals(4, resultado.getStock());

        verify(repository).save(vehiculo);
    }
}