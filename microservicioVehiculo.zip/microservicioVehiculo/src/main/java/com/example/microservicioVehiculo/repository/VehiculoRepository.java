package com.example.microservicioVehiculo.repository;

import com.example.microservicioVehiculo.model.Vehiculo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VehiculoRepository extends JpaRepository<Vehiculo, Long> {
}