package com.example.microservicioVehiculo.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class VehiculoDTO {

    @NotBlank
    private String marca;

    @NotBlank
    private String modelo;

    @Min(1900)
    private int anio;

    @Positive
    private double precio;

    @Min(0)
    private int stock;

    @NotBlank
    private String patente;

    private String estado;
}