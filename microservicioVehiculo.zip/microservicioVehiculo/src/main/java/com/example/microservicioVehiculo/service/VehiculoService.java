package com.example.microservicioVehiculo.service;

import com.example.microservicioVehiculo.model.Vehiculo;
import com.example.microservicioVehiculo.repository.VehiculoRepository;


import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class VehiculoService {

    private final VehiculoRepository repository;

    public Vehiculo crear(Vehiculo vehiculo) {

        if(vehiculo.getStock() < 0){
            throw new RuntimeException("Stock no puede ser negativo");
        }

        vehiculo.setEstado("DISPONIBLE");

        return repository.save(vehiculo);
    }

    public List<Vehiculo> listar() {
        return repository.findAll();
    }

    public Vehiculo obtener(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Vehículo no encontrado"));
    }

    public Vehiculo actualizar(Long id, Vehiculo vehiculo) {
        Vehiculo existente = obtener(id);

        existente.setMarca(vehiculo.getMarca());
        existente.setModelo(vehiculo.getModelo());
        existente.setAnio(vehiculo.getAnio());
        existente.setPrecio(vehiculo.getPrecio());
        existente.setStock(vehiculo.getStock());

        return repository.save(existente);
    }

    public void eliminar(Long id) {
        repository.deleteById(id);
    }

    public Vehiculo reducirStock(Long id) {
        Vehiculo vehiculo = repository.findById(id)
                .orElseThrow();

        vehiculo.setStock(vehiculo.getStock() - 1);

        return repository.save(vehiculo);
    }
}