package com.example.microservicioReporte.controller;

import com.example.microservicioReporte.model.Reporte;
import com.example.microservicioReporte.service.ReporteService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import java.util.List;



@RestController
@RequestMapping("/reportes")
@RequiredArgsConstructor
@SecurityRequirement(name= "bearerAuth")
public class ReporteController {

    private final ReporteService service;

    @PostMapping
    public ResponseEntity<Reporte> crear(@RequestBody Reporte reporte) {
        Reporte rep = service.crear(reporte);
        rep.add(linkTo(methodOn(ReporteController.class).listar()).withRel
                ("todos"));
        rep.add(linkTo(methodOn(ReporteController.class).obtener(rep.getId())).withSelfRel());

        rep.add(linkTo(methodOn(ReporteController.class).actualizar(rep.getId(),rep)).withRel
                ("update"));
        rep.add(linkTo(methodOn(ReporteController.class).eliminar(rep.getId())).withRel
                ("delete"));
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(rep);
    }

    @GetMapping
    public ResponseEntity<List<Reporte>> listar() {
        List<Reporte> lista = service.listar();

        lista.forEach(n -> {
            n.add(linkTo(methodOn(ReporteController.class)
                    .obtener(n.getId()))
                    .withSelfRel());

            n.add(linkTo(methodOn(ReporteController.class)
                    .actualizar(n.getId(), n))
                    .withRel("update"));

            n.add(linkTo(methodOn(ReporteController.class)
                    .eliminar(n.getId()))
                    .withRel("delete"));
        });
        return ResponseEntity.ok(lista);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Reporte> obtener(@PathVariable Long id) {

        Reporte rep = service.obtener(id);

        rep.add(linkTo(methodOn(ReporteController.class)
                .listar())
                .withRel("todos"));

        rep.add(linkTo(methodOn(ReporteController.class)
                .obtener(id))
                .withSelfRel());

        rep.add(linkTo(methodOn(ReporteController.class)
                .actualizar(id,rep))
                .withRel("update"));

        rep.add(linkTo(methodOn(ReporteController.class)
                .eliminar(id))
                .withRel("delete"));
        return ResponseEntity.ok(rep);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Reporte> actualizar(
            @PathVariable Long id,
            @RequestBody Reporte reporte) {
        Reporte rep = service.actualizar(id, reporte);

        rep.add(linkTo(methodOn(ReporteController.class)
                .listar())
                .withRel("todos"));

        rep.add(linkTo(methodOn(ReporteController.class)
                .obtener(id))
                .withSelfRel());

        rep.add(linkTo(methodOn(ReporteController.class)
                .actualizar(id, rep))
                .withRel("update"));

        rep.add(linkTo(methodOn(ReporteController.class)
                .eliminar(id))
                .withRel("delete"));
        return ResponseEntity.ok(rep);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        service.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}