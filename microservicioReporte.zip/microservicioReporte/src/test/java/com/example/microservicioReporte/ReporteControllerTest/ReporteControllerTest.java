package com.example.microservicioReporte.ReporteControllerTest;

import com.example.microservicioReporte.controller.ReporteController;
import com.example.microservicioReporte.model.Reporte;
import com.example.microservicioReporte.service.ReporteService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ReporteControllerTest {

    @Mock
    private ReporteService service;

    @InjectMocks
    private ReporteController controller;

    @Test
    void debeCrearReporte() {

        Reporte reporte = new Reporte();
        reporte.setId(1L);
        reporte.setTipo("Incidencia");
        reporte.setDescripcion("Descripción de prueba");

        when(service.crear(reporte))
                .thenReturn(reporte);

        ResponseEntity<Reporte> response =
                controller.crear(reporte);

        assertNotNull(response.getBody());
        assertEquals("Incidencia",
                response.getBody().getTipo());

        verify(service).crear(reporte);
    }

    @Test
    void debeListarReportes() {

        List<Reporte> lista = Arrays.asList(
                new Reporte(),
                new Reporte()
        );

        when(service.listar()).thenReturn(lista);

        ResponseEntity<List<Reporte>> response =
                controller.listar();

        assertNotNull(response.getBody());
        assertEquals(2, response.getBody().size());

        verify(service).listar();
    }

    @Test
    void debeObtenerReporte() {

        Reporte reporte = new Reporte();
        reporte.setId(1L);
        reporte.setTipo("Incidencia");
        reporte.setDescripcion("Descripción");

        when(service.obtener(1L))
                .thenReturn(reporte);

        ResponseEntity<Reporte> response =
                controller.obtener(1L);

        assertNotNull(response.getBody());
        assertEquals("Incidencia",
                response.getBody().getTipo());

        verify(service).obtener(1L);
    }

    @Test
    void debeActualizarReporte() {

        Reporte reporte = new Reporte();
        reporte.setId(1L);
        reporte.setTipo("Tipo Actualizado");
        reporte.setDescripcion("Descripción Actualizada");

        when(service.actualizar(1L, reporte))
                .thenReturn(reporte);

        ResponseEntity<Reporte> response =
                controller.actualizar(1L, reporte);

        assertNotNull(response.getBody());
        assertEquals("Tipo Actualizado",
                response.getBody().getTipo());

        verify(service).actualizar(1L, reporte);
    }

    @Test
    void debeEliminarReporte() {

        doNothing().when(service).eliminar(1L);

        ResponseEntity<Void> response =
                controller.eliminar(1L);

        assertEquals(204, response.getStatusCode().value());

        verify(service).eliminar(1L);
    }
}