package com.example.microservicioReporte.ReporteServiceTest;

import com.example.microservicioReporte.model.Reporte;
import com.example.microservicioReporte.repository.ReporteRepository;
import com.example.microservicioReporte.service.ReporteService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ReporteServiceTest {

    @Mock
    private ReporteRepository repository;

    @InjectMocks
    private ReporteService service;

    @Test
    void debeGuardarReporte() {

        Reporte reporte = new Reporte();
        reporte.setTipo("Incidencia");
        reporte.setDescripcion("Descripción de prueba");

        when(repository.save(any(Reporte.class)))
                .thenReturn(reporte);

        Reporte resultado = service.crear(reporte);

        assertNotNull(resultado);
        assertEquals("Incidencia", resultado.getTipo());
        assertEquals("Descripción de prueba", resultado.getDescripcion());

        verify(repository).save(any(Reporte.class));
    }

    @Test
    void debeListarReportes() {

        List<Reporte> lista = Arrays.asList(
                new Reporte(),
                new Reporte()
        );

        when(repository.findAll()).thenReturn(lista);

        List<Reporte> resultado = service.listar();

        assertEquals(2, resultado.size());

        verify(repository).findAll();
    }

    @Test
    void debeObtenerReporte() {

        Reporte reporte = new Reporte();

        when(repository.findById(1L))
                .thenReturn(Optional.of(reporte));

        Reporte resultado = service.obtener(1L);

        assertNotNull(resultado);

        verify(repository).findById(1L);
    }

    @Test
    void debeActualizarReporte() {

        Reporte existente = new Reporte();
        existente.setTipo("Tipo antiguo");
        existente.setDescripcion("Descripción antigua");

        Reporte actualizado = new Reporte();
        actualizado.setTipo("Tipo nuevo");
        actualizado.setDescripcion("Descripción nueva");

        when(repository.findById(1L))
                .thenReturn(Optional.of(existente));

        when(repository.save(any(Reporte.class)))
                .thenReturn(existente);

        Reporte resultado = service.actualizar(1L, actualizado);

        assertEquals("Tipo nuevo", resultado.getTipo());
        assertEquals("Descripción nueva", resultado.getDescripcion());

        verify(repository).findById(1L);
        verify(repository).save(existente);
    }

    @Test
    void debeEliminarReporte() {

        service.eliminar(1L);

        verify(repository).deleteById(1L);
    }
}