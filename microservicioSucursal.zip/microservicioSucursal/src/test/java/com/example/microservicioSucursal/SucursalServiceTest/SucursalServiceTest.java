package com.example.microservicioSucursal.SucursalServiceTest;

import com.example.microservicioSucursal.model.Sucursal;
import com.example.microservicioSucursal.repository.SucursalRepository;
import com.example.microservicioSucursal.service.SucursalService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SucursalServiceTest {

    @Mock
    private SucursalRepository repository;

    @InjectMocks
    private SucursalService service;

    @Test
    void debeGuardarSucursal() {

        Sucursal Sucursal = new Sucursal();
        Sucursal.setNombre("Prueba");
        Sucursal.setDireccion("Prueba");
        Sucursal.setCiudad("Prueba");

        when(repository.save(Sucursal))
                .thenReturn(Sucursal);

        Sucursal resultado = service.crear(Sucursal);

        assertNotNull(resultado);
        assertEquals("Prueba", resultado.getNombre());
        assertEquals("Prueba", resultado.getDireccion());
        assertEquals("Prueba", resultado.getCiudad());

        verify(repository).save(Sucursal);
    }

    @Test
    void debeListarSucursales() {

        List<Sucursal> lista = Arrays.asList(
                new Sucursal(),
                new Sucursal()
        );

        when(repository.findAll()).thenReturn(lista);

        List<Sucursal> resultado = service.listar();

        assertEquals(2, resultado.size());

        verify(repository).findAll();
    }

    @Test
    void debeObtenerSucursal() {

        Sucursal Sucursal = new Sucursal();

        when(repository.findById(1L))
                .thenReturn(Optional.of(Sucursal));

        Sucursal resultado = service.obtener(1L);

        assertNotNull(resultado);

        verify(repository).findById(1L);
    }

    @Test
    void debeActualizarSucursal() {

        Sucursal existente = new Sucursal();
        existente.setNombre("nombre antiguo");
        existente.setDireccion("direccion antigua");
        existente.setCiudad("direccion antigua");

        Sucursal actualizada = new Sucursal();
        actualizada.setNombre("nombre nuevo");
        actualizada.setDireccion("direccion nueva");
        actualizada.setCiudad("ciudad nueva");

        when(repository.findById(1L))
                .thenReturn(Optional.of(existente));

        when(repository.save(any(Sucursal.class)))
                .thenReturn(existente);

        Sucursal resultado = service.actualizar(1L, actualizada);

        assertEquals("nombre nuevo", resultado.getNombre());
        assertEquals("direccion nueva", resultado.getDireccion());
        assertEquals("ciudad nueva", resultado.getCiudad());

        verify(repository).findById(1L);
        verify(repository).save(existente);
    }

    @Test
    void debeEliminarSucursal() {

        service.eliminar(1L);

        verify(repository).deleteById(1L);
    }
}