package com.example.microservicioSucursal.SucursalControllerTest;

import com.example.microservicioSucursal.controller.SucursalController;
import com.example.microservicioSucursal.model.Sucursal;
import com.example.microservicioSucursal.service.SucursalService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SucursalControllerTest {

    @Mock
    private SucursalService service;

    @InjectMocks
    private SucursalController controller;

    @Test
    void debeGuardarSucursal() {

        Sucursal sucursal = new Sucursal();
        sucursal.setNombre("Prueba");
        sucursal.setDireccion("Prueba");
        sucursal.setCiudad("Prueba");

        when(service.crear(sucursal))
                .thenReturn(sucursal);

        ResponseEntity<Sucursal> response =
                controller.crear(sucursal);

        assertNotNull(response.getBody());
        assertEquals("Prueba", response.getBody().getNombre());
        assertEquals("Prueba", response.getBody().getDireccion());
        assertEquals("Prueba", response.getBody().getCiudad());

        verify(service).crear(sucursal);
    }

    @Test
    void debeListarSucursales() {

        List<Sucursal> lista = Arrays.asList(
                new Sucursal(),
                new Sucursal()
        );

        when(service.listar()).thenReturn(lista);

        ResponseEntity<List<Sucursal>> response =
                controller.listar();

        assertNotNull(response.getBody());
        assertEquals(2, response.getBody().size());

        verify(service).listar();
    }

    @Test
    void debeObtenerSucursal() {

        Sucursal sucursal = new Sucursal();
        sucursal.setId(1L);
        sucursal.setNombre("Sucursal Test");

        when(service.obtener(1L))
                .thenReturn(sucursal);

        ResponseEntity<Sucursal> response =
                controller.obtener(1L);

        assertNotNull(response.getBody());
        assertEquals("Sucursal Test",
                response.getBody().getNombre());

        verify(service).obtener(1L);
    }

    @Test
    void debeActualizarSucursal() {

        Sucursal sucursal = new Sucursal();
        sucursal.setId(1L);
        sucursal.setNombre("Sucursal Actualizada");
        sucursal.setDireccion("Nueva Dirección");
        sucursal.setCiudad("Nueva Ciudad");

        when(service.actualizar(1L, sucursal))
                .thenReturn(sucursal);

        ResponseEntity<Sucursal> response =
                controller.actualizar(1L, sucursal);

        assertNotNull(response.getBody());
        assertEquals("Sucursal Actualizada",
                response.getBody().getNombre());

        verify(service).actualizar(1L, sucursal);
    }

    @Test
    void debeEliminarSucursal() {

        doNothing().when(service).eliminar(1L);

        ResponseEntity<Void> response =
                controller.eliminar(1L);

        assertEquals(204, response.getStatusCode().value());

        verify(service).eliminar(1L);
    }
}