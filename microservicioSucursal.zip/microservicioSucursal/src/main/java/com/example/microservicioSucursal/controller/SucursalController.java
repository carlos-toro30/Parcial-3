package com.example.microservicioSucursal.controller;

import com.example.microservicioSucursal.model.Sucursal;
import com.example.microservicioSucursal.service.SucursalService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("/sucursales")
@RequiredArgsConstructor
@SecurityRequirement(name= "bearerAuth")
public class SucursalController {

    private final SucursalService service;

    @PostMapping
    public ResponseEntity<Sucursal> crear(@RequestBody Sucursal sucursal) {
        Sucursal suc = service.crear(sucursal);
        suc.add(linkTo(methodOn(SucursalController.class).listar()).withRel
                ("todos"));
        suc.add(linkTo(methodOn(SucursalController.class).obtener(suc.getId())).withSelfRel());

        suc.add(linkTo(methodOn(SucursalController.class).actualizar(suc.getId(),suc)).withRel
                ("update"));
        suc.add(linkTo(methodOn(SucursalController.class).eliminar(suc.getId())).withRel
                ("delete"));
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(suc);
    }

    @GetMapping
    public ResponseEntity<List<Sucursal>> listar() {
        List<Sucursal> lista = service.listar();

        lista.forEach(n -> {
            n.add(linkTo(methodOn(SucursalController.class)
                    .obtener(n.getId()))
                    .withSelfRel());

            n.add(linkTo(methodOn(SucursalController.class)
                    .actualizar(n.getId(), n))
                    .withRel("update"));

            n.add(linkTo(methodOn(SucursalController.class)
                    .eliminar(n.getId()))
                    .withRel("delete"));
        });
        return ResponseEntity.ok(lista);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Sucursal> obtener(@PathVariable Long id) {
        Sucursal suc = service.obtener(id);

        suc.add(linkTo(methodOn(SucursalController.class)
                .listar())
                .withRel("todos"));

        suc.add(linkTo(methodOn(SucursalController.class)
                .obtener(id))
                .withSelfRel());

        suc.add(linkTo(methodOn(SucursalController.class)
                .actualizar(id,suc))
                .withRel("update"));

        suc.add(linkTo(methodOn(SucursalController.class)
                .eliminar(id))
                .withRel("delete"));
        return ResponseEntity.ok(suc);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Sucursal> actualizar(
            @PathVariable Long id,
            @RequestBody Sucursal sucursal) {
        Sucursal suc = service.actualizar(id, sucursal);

        suc.add(linkTo(methodOn(SucursalController.class)
                .listar())
                .withRel("todos"));

        suc.add(linkTo(methodOn(SucursalController.class)
                .obtener(id))
                .withSelfRel());

        suc.add(linkTo(methodOn(SucursalController.class)
                .actualizar(id, suc))
                .withRel("update"));

        suc.add(linkTo(methodOn(SucursalController.class)
                .eliminar(id))
                .withRel("delete"));
        return ResponseEntity.ok(suc);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        service.eliminar(id);
        return ResponseEntity.noContent().build();
    }

}