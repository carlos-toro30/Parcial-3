package com.example.microservicioSucursal.service;

import com.example.microservicioSucursal.model.Sucursal;
import com.example.microservicioSucursal.repository.SucursalRepository;


import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class SucursalService {

    private final SucursalRepository repository;

    public Sucursal crear(Sucursal sucursal) {
        return repository.save(sucursal);
    }

    public List<Sucursal> listar() {
        return repository.findAll();
    }

    public Sucursal obtener(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Sucursal no encontrada"));
    }

    public Sucursal actualizar(Long id, Sucursal sucursal) {
        Sucursal existente = obtener(id);

        existente.setNombre(sucursal.getNombre());
        existente.setDireccion(sucursal.getDireccion());
        existente.setCiudad(sucursal.getCiudad());

        return repository.save(existente);
    }

    public void eliminar(Long id) {
        repository.deleteById(id);
    }
}