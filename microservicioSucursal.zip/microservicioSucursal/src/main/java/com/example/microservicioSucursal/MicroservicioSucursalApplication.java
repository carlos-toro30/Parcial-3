package com.example.microservicioSucursal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication

@EnableJpaRepositories(basePackages = "com.example.microservicioSucursal.repository")
public class MicroservicioSucursalApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicioSucursalApplication.class, args);
	}

}
