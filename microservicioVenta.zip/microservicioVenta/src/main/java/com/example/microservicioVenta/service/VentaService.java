package com.example.microservicioVenta.service;

import com.example.microservicioVenta.FEIGNCLIENTS.ClienteClient;
import com.example.microservicioVenta.FEIGNCLIENTS.VehiculoClient;
import com.example.microservicioVenta.model.Venta;
import com.example.microservicioVenta.repository.VentaRepository;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class VentaService {

    private final VentaRepository repository;
    private final ClienteClient clienteClient;
    private final VehiculoClient vehiculoClient;

    public Venta crear (Venta venta) {

        // validar cliente
        try {
            clienteClient.obtenerCliente(venta.getClienteId());
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Cliente no existe");
        }

        // validar vehiculo
        try {
            vehiculoClient.obtenerVehiculo(venta.getVehiculoId());
        } catch (Exception e) {
            throw new RuntimeException("Vehículo no existe");
        }

        // reducir stock
        vehiculoClient.reducirStock(venta.getVehiculoId());

        venta.setFecha(LocalDateTime.now());
        venta.setEstado("COMPLETADA");

        return repository.save(venta);
    }

    public List<Venta> listar() {
        return repository.findAll();
    }

    public Venta obtener(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Venta no encontrada"));
    }
}