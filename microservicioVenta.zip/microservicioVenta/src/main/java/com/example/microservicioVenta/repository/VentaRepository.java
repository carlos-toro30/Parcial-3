package com.example.microservicioVenta.repository;

import com.example.microservicioVenta.model.Venta;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VentaRepository extends JpaRepository<Venta, Long> {
}