package com.example.microservicioVenta.controller;

import com.example.microservicioVenta.model.Venta;
import com.example.microservicioVenta.service.VentaService;


import lombok.RequiredArgsConstructor;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("/ventas")
@RequiredArgsConstructor
public class VentaController {

    private final VentaService service;

    @PostMapping
    public ResponseEntity<EntityModel<Venta>> crear(@RequestBody Venta venta) {

        Venta nuevaVenta = service.crear(venta);

        EntityModel<Venta> recurso = EntityModel.of(nuevaVenta,
                linkTo(methodOn(VentaController.class)
                        .obtener(nuevaVenta.getId()))
                        .withSelfRel(),

                linkTo(methodOn(VentaController.class)
                        .listar())
                        .withRel("ventas"));

        return ResponseEntity.ok(recurso);
    }

    @GetMapping
    public ResponseEntity<CollectionModel<EntityModel<Venta>>> listar() {

        List<EntityModel<Venta>> ventas = service.listar().stream()
                .map(venta -> EntityModel.of(venta,
                        linkTo(methodOn(VentaController.class)
                                .obtener(venta.getId()))
                                .withSelfRel()))
                .toList();

        CollectionModel<EntityModel<Venta>> collection =
                CollectionModel.of(ventas,
                        linkTo(methodOn(VentaController.class)
                                .listar())
                                .withSelfRel());

        return ResponseEntity.ok(collection);
    }

    @GetMapping("/{id}")
    public ResponseEntity<EntityModel<Venta>> obtener(@PathVariable Long id) {

        Venta venta = service.obtener(id);

        EntityModel<Venta> recurso = EntityModel.of(venta,
                linkTo(methodOn(VentaController.class)
                        .obtener(id))
                        .withSelfRel(),

                linkTo(methodOn(VentaController.class)
                        .listar())
                        .withRel("ventas"));

        return ResponseEntity.ok(recurso);
    }
}