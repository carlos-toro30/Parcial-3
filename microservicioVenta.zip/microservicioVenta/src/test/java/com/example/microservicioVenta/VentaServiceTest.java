package com.example.microservicioVenta;

import com.example.microservicioVenta.FEIGNCLIENTS.ClienteClient;
import com.example.microservicioVenta.FEIGNCLIENTS.VehiculoClient;
import com.example.microservicioVenta.model.Venta;
import com.example.microservicioVenta.repository.VentaRepository;

import com.example.microservicioVenta.service.VentaService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class VentaServiceTest {

    @Mock
    private VentaRepository repository;

    @Mock
    private ClienteClient clienteClient;

    @Mock
    private VehiculoClient vehiculoClient;

    @InjectMocks
    private VentaService service;

    private Venta venta;

    @BeforeEach
    void setUp() {
        venta = new Venta();
        venta.setId(1L);
        venta.setClienteId(10L);
        venta.setVehiculoId(20L);
    }

    @Test
    void crearDebeGuardarVenta() {

        // cliente existe
        when(clienteClient.obtenerCliente(10L))
                .thenReturn(null);

        // vehículo existe
        when(vehiculoClient.obtenerVehiculo(20L))
                .thenReturn(null);

        when(repository.save(any(Venta.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        Venta resultado = service.crear(venta);

        assertNotNull(resultado.getFecha());
        assertEquals("COMPLETADA", resultado.getEstado());

        verify(clienteClient).obtenerCliente(10L);
        verify(vehiculoClient).obtenerVehiculo(20L);
        verify(vehiculoClient).reducirStock(20L);
        verify(repository).save(any(Venta.class));
    }

    @Test
    void crearDebeLanzarExcepcionSiClienteNoExiste() {

        when(clienteClient.obtenerCliente(10L))
                .thenThrow(new RuntimeException());

        RuntimeException ex = assertThrows(
                RuntimeException.class,
                () -> service.crear(venta)
        );

        assertEquals("Cliente no existe", ex.getMessage());

        verify(repository, never()).save(any());
    }

    @Test
    void crearDebeLanzarExcepcionSiVehiculoNoExiste() {

        when(clienteClient.obtenerCliente(10L))
                .thenReturn(null);

        when(vehiculoClient.obtenerVehiculo(20L))
                .thenThrow(new RuntimeException());

        RuntimeException ex = assertThrows(
                RuntimeException.class,
                () -> service.crear(venta)
        );

        assertEquals("Vehículo no existe", ex.getMessage());

        verify(repository, never()).save(any());
    }

    @Test
    void listarDebeRetornarVentas() {

        when(repository.findAll())
                .thenReturn(List.of(venta));

        List<Venta> ventas = service.listar();

        assertEquals(1, ventas.size());

        verify(repository).findAll();
    }

    @Test
    void obtenerDebeRetornarVenta() {

        when(repository.findById(1L))
                .thenReturn(Optional.of(venta));

        Venta resultado = service.obtener(1L);

        assertEquals(1L, resultado.getId());
    }

    @Test
    void obtenerDebeLanzarExcepcionSiNoExiste() {

        when(repository.findById(1L))
                .thenReturn(Optional.empty());

        RuntimeException ex = assertThrows(
                RuntimeException.class,
                () -> service.obtener(1L)
        );

        assertEquals("Venta no encontrada", ex.getMessage());
    }
}