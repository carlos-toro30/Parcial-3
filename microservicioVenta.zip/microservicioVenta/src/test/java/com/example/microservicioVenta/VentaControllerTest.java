package com.example.microservicioVenta;

import com.example.microservicioVenta.controller.VentaController;
import com.example.microservicioVenta.model.Venta;
import com.example.microservicioVenta.service.VentaService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;


@ExtendWith(MockitoExtension.class)
class VentaControllerTest {

    @Mock
    private VentaService service;

    @InjectMocks
    private VentaController controller;

    @Test
    void deberiaCrearVenta() {

        Venta venta = new Venta();
        venta.setId(1L);

        when(service.crear(any(Venta.class)))
                .thenReturn(venta);

        ResponseEntity<EntityModel<Venta>> respuesta =
                controller.crear(venta);

        assertEquals(200, respuesta.getStatusCodeValue());
        assertNotNull(respuesta.getBody());
        assertEquals(1L,
                respuesta.getBody().getContent().getId());

        verify(service).crear(venta);
    }

    @Test
    void deberiaListarVentas() {

        Venta venta = new Venta();
        venta.setId(1L);

        when(service.listar())
                .thenReturn(List.of(venta));

        ResponseEntity<CollectionModel<EntityModel<Venta>>> respuesta =
                controller.listar();

        assertEquals(200, respuesta.getStatusCodeValue());
        assertNotNull(respuesta.getBody());

        verify(service).listar();
    }

    @Test
    void deberiaObtenerVentaPorId() {

        Venta venta = new Venta();
        venta.setId(1L);

        when(service.obtener(1L))
                .thenReturn(venta);

        ResponseEntity<EntityModel<Venta>> respuesta =
                controller.obtener(1L);

        assertEquals(200, respuesta.getStatusCodeValue());
        assertNotNull(respuesta.getBody());
        assertEquals(1L,
                respuesta.getBody().getContent().getId());

        verify(service).obtener(1L);
    }
}
