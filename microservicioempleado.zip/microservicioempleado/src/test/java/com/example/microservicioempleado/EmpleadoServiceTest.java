package com.example.microservicioempleado;




import com.example.microservicioempleado.client.SucursalClient;
import com.example.microservicioempleado.model.Empleado;
import com.example.microservicioempleado.repository.EmpleadoRepository;
import com.example.microservicioempleado.service.EmpleadoService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class EmpleadoServiceTest {

    @Mock
    private EmpleadoRepository repo;

    @Mock
    private SucursalClient sucursalClient;

    @InjectMocks
    private EmpleadoService service;

    @Test
    void deberiaCrearEmpleado() {

        Empleado empleado = new Empleado();
        empleado.setId(1L);
        empleado.setSucursalId(1L);

        when(repo.save(any(Empleado.class)))
                .thenReturn(empleado);

        Empleado resultado = service.crear(empleado);

        assertNotNull(resultado);
        assertEquals(1L, resultado.getId());

        verify(sucursalClient).obtenerSucursal(1L);
        verify(repo).save(empleado);
    }

    @Test
    void deberiaLanzarErrorSiSucursalIdEsNull() {

        Empleado empleado = new Empleado();

        RuntimeException exception = assertThrows(
                RuntimeException.class,
                () -> service.crear(empleado)
        );

        assertEquals(
                "Debe enviar sucursalId",
                exception.getMessage()
        );
    }

    @Test
    void deberiaListarEmpleados() {

        Empleado empleado = new Empleado();
        empleado.setId(1L);

        when(repo.findAll())
                .thenReturn(List.of(empleado));

        List<Empleado> resultado = service.listar();

        assertEquals(1, resultado.size());

        verify(repo).findAll();
    }

    @Test
    void deberiaObtenerEmpleadoPorId() {

        Empleado empleado = new Empleado();
        empleado.setId(1L);

        when(repo.findById(1L))
                .thenReturn(Optional.of(empleado));

        Empleado resultado = service.obtener(1L);

        assertNotNull(resultado);
        assertEquals(1L, resultado.getId());

        verify(repo).findById(1L);
    }

    @Test
    void deberiaLanzarErrorSiEmpleadoNoExiste() {

        when(repo.findById(1L))
                .thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(
                RuntimeException.class,
                () -> service.obtener(1L)
        );

        assertEquals(
                "Empleado no encontrado",
                exception.getMessage()
        );
    }

    @Test
    void deberiaActualizarEmpleado() {

        Empleado existente = new Empleado();
        existente.setId(1L);
        existente.setNombre("Juan");

        Empleado nuevo = new Empleado();
        nuevo.setNombre("Pedro");
        nuevo.setCorreo("pedro@gmail.com");
        nuevo.setRol("ADMIN");
        nuevo.setSucursalId(1L);

        when(repo.findById(1L))
                .thenReturn(Optional.of(existente));

        when(repo.save(any(Empleado.class)))
                .thenAnswer(i -> i.getArgument(0));

        Empleado resultado = service.actualizar(1L, nuevo);

        assertEquals("Pedro", resultado.getNombre());
        assertEquals("pedro@gmail.com", resultado.getCorreo());
        assertEquals("ADMIN", resultado.getRol());
        assertEquals(1L, resultado.getSucursalId());

        verify(sucursalClient).obtenerSucursal(1L);
        verify(repo).save(existente);
    }

    @Test
    void deberiaEliminarEmpleado() {

        when(repo.existsById(1L))
                .thenReturn(true);

        service.eliminar(1L);

        verify(repo).deleteById(1L);
    }

    @Test
    void deberiaLanzarErrorAlEliminarSiNoExiste() {

        when(repo.existsById(1L))
                .thenReturn(false);

        RuntimeException exception = assertThrows(
                RuntimeException.class,
                () -> service.eliminar(1L)
        );

        assertEquals(
                "Empleado no encontrado",
                exception.getMessage()
        );
    }
}