package com.example.microservicioempleado;

import com.example.microservicioempleado.controller.EmpleadoController;
import com.example.microservicioempleado.model.Empleado;
import com.example.microservicioempleado.service.EmpleadoService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
@ExtendWith(MockitoExtension.class)
public class EmpleadoControllerTest {
    @Mock
    private EmpleadoService service;

    @InjectMocks
    private EmpleadoController controller;

    @Test
    void deberiaCrearEmpleado() {

        Empleado empleado = new Empleado();
        empleado.setId(1L);

        when(service.crear(any(Empleado.class)))
                .thenReturn(empleado);

        ResponseEntity<Empleado> respuesta =
                controller.crear(empleado);

        assertEquals(HttpStatus.CREATED,
                respuesta.getStatusCode());

        assertNotNull(respuesta.getBody());

        assertEquals(1L,
                respuesta.getBody().getId());

        verify(service).crear(empleado);
    }

    @Test
    void deberiaListarEmpleados() {

        Empleado empleado = new Empleado();
        empleado.setId(1L);

        when(service.listar())
                .thenReturn(List.of(empleado));

        ResponseEntity<List<Empleado>> respuesta =
                controller.listar();

        assertEquals(HttpStatus.OK,
                respuesta.getStatusCode());

        assertEquals(1,
                respuesta.getBody().size());

        verify(service).listar();
    }



    @Test
    void deberiaObtenerEmpleadosPorId() {

        Empleado empleado = new Empleado();
        empleado.setId(1L);

        when(service.obtener(1L))
                .thenReturn(empleado);

        ResponseEntity<Empleado> respuesta =
                controller.obtener(1L);

        assertEquals(HttpStatus.OK,
                respuesta.getStatusCode());

        assertNotNull(respuesta.getBody());

        assertEquals(1L,
                respuesta.getBody().getId());

        verify(service).obtener(1L);
    }
}
