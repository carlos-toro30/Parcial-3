package com.example.microservicioempleado.controller;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import com.example.microservicioempleado.model.Empleado;
import com.example.microservicioempleado.service.EmpleadoService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/empleados")
@RequiredArgsConstructor
public class EmpleadoController {

    private final EmpleadoService service;
    @PostMapping
    public ResponseEntity<Empleado> crear(@Valid @RequestBody Empleado empleado) {
        Empleado emp = service.crear(empleado);
        emp.add(linkTo(methodOn(EmpleadoController.class).listar()).withRel
                ("todos"));
        emp.add(linkTo(methodOn(EmpleadoController.class).obtener(emp.getId()
        )).withSelfRel());
        emp.add(linkTo(methodOn(EmpleadoController.class).actualizar(emp.getId(),empleado)).withRel("update"));
        emp.add(linkTo(methodOn(EmpleadoController.class).eliminar(emp.getId())).withRel("delete"));
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(emp);
    }



    @GetMapping
    public ResponseEntity<List<Empleado>> listar() {
        List<Empleado> lista = service.listar();

        lista.forEach(v -> {
            v.add(linkTo(methodOn(EmpleadoController.class)
                    .obtener(v.getId()))
                    .withSelfRel());

            v.add(linkTo(methodOn(EmpleadoController.class)
                    .actualizar(v.getId(), null))
                    .withRel("update"));

            v.add(linkTo(methodOn(EmpleadoController.class)
                    .eliminar(v.getId()))
                    .withRel("delete"));
        });

        return ResponseEntity.ok(lista);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Empleado> obtener(@PathVariable Long id) {
        Empleado empleado = service.obtener(id);

        empleado.add(linkTo(methodOn(EmpleadoController.class)
                .obtener(id))
                .withSelfRel());

        empleado.add(linkTo(methodOn(EmpleadoController.class)
                .listar())
                .withRel("todos"));

        empleado.add(linkTo(methodOn(EmpleadoController.class)
                .actualizar(id, null))
                .withRel("update"));

        empleado.add(linkTo(methodOn(EmpleadoController.class)
                .eliminar(id))
                .withRel("delete"));

        return ResponseEntity.ok(empleado);

    }

    @PutMapping("/{id}")
    public ResponseEntity<Empleado> actualizar(
            @PathVariable Long id,
            @RequestBody Empleado empleado) {

        Empleado actualizado = service.actualizar(id, empleado);

        actualizado.add(linkTo(methodOn(EmpleadoController.class)
                .obtener(id))
                .withSelfRel());

        actualizado.add(linkTo(methodOn(EmpleadoController.class)
                .listar())
                .withRel("todos"));

        actualizado.add(linkTo(methodOn(EmpleadoController.class)
                .eliminar(id))
                .withRel("delete"));

        return ResponseEntity.ok(actualizado);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        service.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}