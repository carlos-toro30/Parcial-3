package com.example.microservicioempleado.repository;


import com.example.microservicioempleado.model.Empleado;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmpleadoRepository extends JpaRepository<Empleado, Long> {
}