package com.example.microservicioauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioauthApplicationTests {

	@Test
	void contextLoads() {
	}

}
