package com.example.microservicioauth;

import com.example.microservicioauth.controller.AuthController;
import com.example.microservicioauth.model.Usuario;
import com.example.microservicioauth.service.AuthService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class AuthControllerTest {

    @Mock
    private AuthService service;

    @InjectMocks
    private AuthController controller;

    @Test
    void deberiaRegistrarUsuario() {

        Usuario usuario = new Usuario();
        usuario.setId(1L);
        usuario.setUsername("carlos");
        usuario.setPassword("1234");

        when(service.registrar(any(Usuario.class)))
                .thenReturn(usuario);

        Usuario respuesta = controller.register(usuario);

        assertNotNull(respuesta);

        assertEquals(1L,
                respuesta.getId());

        assertEquals("carlos",
                respuesta.getUsername());

        verify(service).registrar(usuario);
    }

    @Test
    void deberiaIniciarSesion() {

        Map<String, String> request = new HashMap<>();
        request.put("username", "carlos");
        request.put("password", "1234");

        when(service.login("carlos", "1234"))
                .thenReturn("token-jwt");

        String respuesta = controller.login(request);

        assertNotNull(respuesta);

        assertEquals("token-jwt",
                respuesta);

        verify(service).login("carlos", "1234");
    }
}