package com.example.microservicioauth;

import com.example.microservicioauth.model.Usuario;
import com.example.microservicioauth.repository.UsuarioRepository;
import com.example.microservicioauth.security.JwtUtil;
import com.example.microservicioauth.service.AuthService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AuthServiceTest {

    @Mock
    private UsuarioRepository repository;

    @Mock
    private JwtUtil jwtUtil;

    @InjectMocks
    private AuthService authService;

    @Test
    void deberiaGenerarToken() {

        Usuario usuario = new Usuario();
        usuario.setUsername("Valentin");
        usuario.setPassword("1234");

        when(repository.findByUsername("Valentin"))
                .thenReturn(Optional.of(usuario));

        when(jwtUtil.generarToken("Valentin"))
                .thenReturn("token123");

        String token = authService.login("Valentin", "1234");

        assertEquals("token123", token);

        verify(repository).findByUsername("Valentin");
        verify(jwtUtil).generarToken("Valentin");
    }
}