package com.example.microservicionotificacion.NotificacionService;

import com.example.microservicionotificacion.model.Notificacion;
import com.example.microservicionotificacion.repository.NotificacionRepository;
import com.example.microservicionotificacion.service.NotificacionService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class NotificacionServiceTest {

    @Mock
    private NotificacionRepository repository;

    @InjectMocks
    private NotificacionService service;

    @Test
    void debeGuardarNotificacion() {

        Notificacion notificacion = new Notificacion();
        notificacion.setMensaje("Prueba");

        when(repository.save(notificacion))
                .thenReturn(notificacion);

        Notificacion resultado = service.enviar(notificacion);

        assertNotNull(resultado);
        assertEquals("Prueba", resultado.getMensaje());

        verify(repository).save(notificacion);
    }

    @Test
    void debeListarNotificaciones() {

        List<Notificacion> lista = Arrays.asList(
                new Notificacion(),
                new Notificacion()
        );

        when(repository.findAll()).thenReturn(lista);

        List<Notificacion> resultado = service.listar();

        assertEquals(2, resultado.size());

        verify(repository).findAll();
    }

    @Test
    void debeObtenerNotificacion() {

        Notificacion notificacion = new Notificacion();

        when(repository.findById(1L))
                .thenReturn(Optional.of(notificacion));

        Notificacion resultado = service.obtener(1L);

        assertNotNull(resultado);

        verify(repository).findById(1L);
    }

    @Test
    void debeActualizarNotificacion() {

        Notificacion existente = new Notificacion();
        existente.setMensaje("Mensaje antiguo");
        existente.setDestinatario("Juan");

        Notificacion actualizada = new Notificacion();
        actualizada.setMensaje("Mensaje nuevo");
        actualizada.setDestinatario("Pedro");

        when(repository.findById(1L))
                .thenReturn(Optional.of(existente));

        when(repository.save(any(Notificacion.class)))
                .thenReturn(existente);

        Notificacion resultado = service.actualizar(1L, actualizada);

        assertEquals("Mensaje nuevo", resultado.getMensaje());
        assertEquals("Pedro", resultado.getDestinatario());

        verify(repository).findById(1L);
        verify(repository).save(existente);
    }

    @Test
    void debeEliminarNotificacion() {

        service.eliminar(1L);

        verify(repository).deleteById(1L);
    }
}