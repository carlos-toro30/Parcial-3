package com.example.microservicionotificacion.NotificacionController;

import com.example.microservicionotificacion.controller.NotificacionController;
import com.example.microservicionotificacion.model.Notificacion;
import com.example.microservicionotificacion.service.NotificacionService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class NotificacionControllerTest {

    @Mock
    private NotificacionService service;

    @InjectMocks
    private NotificacionController controller;

    @Test
    void debeGuardarNotificacion() {

        Notificacion notificacion = new Notificacion();
        notificacion.setMensaje("Prueba");

        when(service.enviar(notificacion))
                .thenReturn(notificacion);

        ResponseEntity<Notificacion> response =
                controller.enviar(notificacion);

        assertNotNull(response.getBody());
        assertEquals("Prueba", response.getBody().getMensaje());

        verify(service).enviar(notificacion);
    }

    @Test
    void debeListarNotificaciones() {

        List<Notificacion> lista = Arrays.asList(
                new Notificacion(),
                new Notificacion()
        );

        when(service.listar()).thenReturn(lista);

        ResponseEntity<List<Notificacion>> response =
                controller.listar();

        assertNotNull(response.getBody());
        assertEquals(2, response.getBody().size());

        verify(service, atLeastOnce()).listar();
    }

    @Test
    void debeObtenerNotificacion() {

        Notificacion notificacion = new Notificacion();
        notificacion.setIdNotificacion(1L);
        notificacion.setMensaje("Prueba");

        when(service.obtener(1L)).thenReturn(notificacion);

        ResponseEntity<Notificacion> response =
                controller.obtener(1L);

        assertNotNull(response.getBody());
        assertEquals("Prueba", response.getBody().getMensaje());

        verify(service,times(2)).obtener(1L);
    }

    @Test
    void debeActualizarNotificacion() {

        Notificacion notificacion = new Notificacion();
        notificacion.setIdNotificacion(1L);
        notificacion.setMensaje("Actualizada");

        when(service.actualizar(1L, notificacion))
                .thenReturn(notificacion);

        ResponseEntity<Notificacion> response =
                controller.actualizar(1L, notificacion);

        assertNotNull(response.getBody());
        assertEquals("Actualizada",
                response.getBody().getMensaje());

        verify(service,times(2)).actualizar(1L, notificacion);
    }

    @Test
    void debeEliminarNotificacion() {

        doNothing().when(service).eliminar(1L);

        ResponseEntity<Void> response =
                controller.eliminar(1L);

        assertEquals(204, response.getStatusCode().value());

        verify(service).eliminar(1L);
    }
}