package com.example.microservicionotificacion.repository;


import com.example.microservicionotificacion.model.Notificacion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NotificacionRepository extends JpaRepository<Notificacion, Long> {

}