package com.example.microservicionotificacion.service;


import com.example.microservicionotificacion.model.Notificacion;
import com.example.microservicionotificacion.repository.NotificacionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class NotificacionService {

    private final NotificacionRepository repository;

    public Notificacion enviar(Notificacion notificacion) {
        return repository.save(notificacion);
    }

    public List<Notificacion> listar()  {
        return repository.findAll();
    }

    public Notificacion obtener(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Cliente no encontrado"));
    }

    public Notificacion actualizar(Long id, Notificacion notificacion) {
        Notificacion existente = obtener(id);

        existente.setMensaje(notificacion.getMensaje());
        existente.setDestinatario(notificacion.getDestinatario());

        return repository.save(existente);
    }

    public void eliminar(Long id) {
        repository.deleteById(id);
    }
}