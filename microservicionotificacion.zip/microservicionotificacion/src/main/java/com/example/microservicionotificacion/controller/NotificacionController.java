package com.example.microservicionotificacion.controller;



import com.example.microservicionotificacion.model.Notificacion;
import com.example.microservicionotificacion.service.NotificacionService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import java.util.List;

@RestController
@RequestMapping("/notificaciones")
@RequiredArgsConstructor
@SecurityRequirement(name= "bearerAuth")
public class NotificacionController {

    private final NotificacionService service;

    @PostMapping
    public ResponseEntity<Notificacion> enviar(@RequestBody Notificacion notificacion) {
        Notificacion not = service.enviar(notificacion);
        not.add(linkTo(methodOn(NotificacionController.class).listar()).withRel
                ("todos"));
        not.add(linkTo(methodOn(NotificacionController.class).obtener(not.getIdNotificacion())).withSelfRel());

        not.add(linkTo(methodOn(NotificacionController.class).actualizar(not.getIdNotificacion(),not)).withRel
                ("update"));
        not.add(linkTo(methodOn(NotificacionController.class).eliminar(not.getIdNotificacion())).withRel
                ("delete"));
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(not);
    }

    @GetMapping
    public ResponseEntity<List<Notificacion>> listar() {
         List<Notificacion> lista = service.listar();

        lista.forEach(n -> {
            n.add(linkTo(methodOn(NotificacionController.class)
                    .obtener(n.getIdNotificacion()))
                    .withSelfRel());

            n.add(linkTo(methodOn(NotificacionController.class)
                    .actualizar(n.getIdNotificacion(), n))
                    .withRel("update"));

            n.add(linkTo(methodOn(NotificacionController.class)
                    .eliminar(n.getIdNotificacion()))
                    .withRel("delete"));
        });
        return ResponseEntity.ok(service.listar());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Notificacion> obtener(@PathVariable Long id) {
        Notificacion not = service.obtener(id);

        not.add(linkTo(methodOn(NotificacionController.class)
                .listar())
                .withRel("todos"));

        not.add(linkTo(methodOn(NotificacionController.class)
                .obtener(id))
                .withSelfRel());

        not.add(linkTo(methodOn(NotificacionController.class)
                .actualizar(id, not))
                .withRel("update"));

        not.add(linkTo(methodOn(NotificacionController.class)
                .eliminar(id))
                .withRel("delete"));
        return ResponseEntity.ok(service.obtener(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Notificacion> actualizar(
            @PathVariable Long id,
            @RequestBody Notificacion notificacion) {
        Notificacion not = service.actualizar(id, notificacion);

        not.add(linkTo(methodOn(NotificacionController.class)
                .listar())
                .withRel("todos"));

        not.add(linkTo(methodOn(NotificacionController.class)
                .obtener(id))
                .withSelfRel());

        not.add(linkTo(methodOn(NotificacionController.class)
                .actualizar(id, not))
                .withRel("update"));

        not.add(linkTo(methodOn(NotificacionController.class)
                .eliminar(id))
                .withRel("delete"));
        return ResponseEntity.ok(service.actualizar(id, notificacion));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        service.eliminar(id);
        return ResponseEntity.noContent().build();
    }



}