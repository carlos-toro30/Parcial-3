package com.example.microservicioPago;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioPagoApplicationTests {

	@Test
	void contextLoads() {
	}

}
