package com.example.microservicioPago;

import com.example.microservicioPago.feign.VentaClient;
import com.example.microservicioPago.model.Pago;
import com.example.microservicioPago.repository.PagoRepository;
import com.example.microservicioPago.service.PagoService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PagoServiceTest {

    @Mock
    private PagoRepository repository;

    @Mock
    private VentaClient ventaClient;

    @InjectMocks
    private PagoService service;


    @Test
    void crearPago() {

        Pago pago = new Pago();
        pago.setVentaId(1L);

        Pago pagoGuardado = new Pago();
        pagoGuardado.setId(1L);
        pagoGuardado.setVentaId(1L);


        when(ventaClient.obtenerVenta(1L)).thenReturn(null);

        when(repository.save(any(Pago.class)))
                .thenReturn(pagoGuardado);

        Pago resultado = service.crear(pago);

        assertNotNull(resultado);
        assertEquals(1L, resultado.getId());

        verify(ventaClient).obtenerVenta(1L);
        verify(repository).save(any(Pago.class));
    }


    @Test
    void crearPagoVentaNoExiste() {

        Pago pago = new Pago();
        pago.setVentaId(99L);

        when(ventaClient.obtenerVenta(99L))
                .thenThrow(new RuntimeException());

        RuntimeException ex = assertThrows(RuntimeException.class,
                () -> service.crear(pago));

        assertEquals("Venta no existe", ex.getMessage());

        verify(repository, never()).save(any());
    }


    @Test
    void listarPagos() {

        when(repository.findAll())
                .thenReturn(List.of(new Pago(), new Pago()));

        List<Pago> lista = service.listar();

        assertEquals(2, lista.size());

        verify(repository).findAll();
    }


    @Test
    void obtenerPago() {

        Pago pago = new Pago();
        pago.setId(1L);

        when(repository.findById(1L))
                .thenReturn(Optional.of(pago));

        Pago resultado = service.obtener(1L);

        assertNotNull(resultado);
        assertEquals(1L, resultado.getId());

        verify(repository).findById(1L);
    }
}