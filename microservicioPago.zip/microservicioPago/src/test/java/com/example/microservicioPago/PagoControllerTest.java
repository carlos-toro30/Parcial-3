package com.example.microservicioPago;

import com.example.microservicioPago.controller.PagoController;
import com.example.microservicioPago.model.Pago;
import com.example.microservicioPago.service.PagoService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PagoControllerTest {

    @Mock
    private PagoService service;

    @InjectMocks
    private PagoController controller;

    @Test
    void deberiaCrearPago() {

        Pago pago = new Pago();
        pago.setId(1L);
        pago.setVentaId(1L);

        when(service.crear(any(Pago.class)))
                .thenReturn(pago);

        ResponseEntity<Pago> respuesta = controller.crear(pago);

        assertEquals(HttpStatus.CREATED, respuesta.getStatusCode());
        assertNotNull(respuesta.getBody());
        assertEquals(1L, respuesta.getBody().getId());
        assertEquals(1L, respuesta.getBody().getVentaId());

        verify(service, times(1)).crear(pago);
    }

    @Test
    void deberiaListarPagos() {

        Pago pago = new Pago();
        pago.setId(1L);
        pago.setVentaId(1L);

        when(service.listar())
                .thenReturn(List.of(pago));

        List<Pago> respuesta = controller.listar();

        assertNotNull(respuesta);
        assertEquals(1, respuesta.size());
        assertEquals(1L, respuesta.get(0).getId());

        verify(service, times(1)).listar();
    }

    @Test
    void deberiaObtenerPagoPorId() {

        Pago pago = new Pago();
        pago.setId(1L);
        pago.setVentaId(1L);

        when(service.obtener(1L))
                .thenReturn(pago);

        Pago respuesta = controller.obtener(1L);

        assertNotNull(respuesta);
        assertEquals(1L, respuesta.getId());
        assertEquals(1L, respuesta.getVentaId());

        verify(service, times(1)).obtener(1L);
    }
}