package com.example.microservicioPago.service;

import com.example.microservicioPago.feign.VentaClient;
import com.example.microservicioPago.model.Pago;
import com.example.microservicioPago.repository.PagoRepository;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class PagoService {

    private final PagoRepository repository;
    private final VentaClient ventaClient;

    public Pago crear(Pago pago) {


        try {
            ventaClient.obtenerVenta(pago.getVentaId());
        } catch (Exception e) {
            throw new RuntimeException("Venta no existe");
        }

        pago.setFecha(LocalDateTime.now());

        return repository.save(pago);
    }

    public List<Pago> listar() {
        return repository.findAll();
    }

    public Pago obtener(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Pago no encontrado"));
    }

    public Pago actualizar(Long id, Pago nuevo) {

        Pago existente = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("pago no encontrado"));


        if (nuevo.getVentaId() != null) {
            ventaClient.obtenerVenta(nuevo.getVentaId());
            existente.setVentaId(nuevo.getVentaId());
        }

        existente.setMonto(nuevo.getMonto());
        existente.setMetodo(nuevo.getMetodo());
        existente.setFecha(nuevo.getFecha());

        return repository.save(existente);
    }

    public void eliminar(Long id) {

        if (!repository.existsById(id)) {
            throw new RuntimeException("Pago no encontrado");
        }

        repository.deleteById(id);
    }


}