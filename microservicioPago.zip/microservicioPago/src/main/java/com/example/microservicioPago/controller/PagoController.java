package com.example.microservicioPago.controller;

import com.example.microservicioPago.model.Pago;
import com.example.microservicioPago.service.PagoService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import java.util.List;

@RestController
@RequestMapping("/pagos")
@RequiredArgsConstructor
public class PagoController {

    private final PagoService service;

    @PostMapping
    public ResponseEntity<Pago> crear (@RequestBody Pago pago) {
        Pago pag = service.crear(pago);
        
        pag.add(linkTo(methodOn(PagoController.class).listar()).withRel
                ("todos"));
        pag.add(linkTo(methodOn(PagoController.class).obtener(pag.getId()
        )).withSelfRel());
        pag.add(linkTo(methodOn(PagoController.class).actualizar(pag.getId(),pago)).withRel("update"));
        pag.add(linkTo(methodOn(PagoController.class).eliminar(pag.getId())).withRel("delete"));
        
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.crear(pago));
    }

    @GetMapping
    public List<Pago> listar() {
        List<Pago> lista = service.listar();

        lista.forEach(v -> {
            v.add(linkTo(methodOn(PagoController.class)
                    .obtener(v.getId()))
                    .withSelfRel());

            v.add(linkTo(methodOn(PagoController.class)
                    .actualizar(v.getId(), null))
                    .withRel("update"));

            v.add(linkTo(methodOn(PagoController.class)
                    .eliminar(v.getId()))
                    .withRel("delete"));
        });
        return service.listar();
    }

    @GetMapping("/{id}")
    public Pago obtener(@PathVariable Long id) {

        Pago pago = service.obtener(id);

        pago.add(linkTo(methodOn(PagoController.class)
                .obtener(id))
                .withSelfRel());

        pago.add(linkTo(methodOn(PagoController.class)
                .listar())
                .withRel("todos"));

        pago.add(linkTo(methodOn(PagoController.class)
                .actualizar(id, null))
                .withRel("update"));

        pago.add(linkTo(methodOn(PagoController.class)
                .eliminar(id))
                .withRel("delete"));

        return service.obtener(id);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Pago> actualizar(
            @PathVariable Long id,
            @RequestBody Pago pago) {

        Pago actualizado = service.actualizar(id, pago);

        actualizado.add(linkTo(methodOn(PagoController.class)
                .obtener(id))
                .withSelfRel());

        actualizado.add(linkTo(methodOn(PagoController.class)
                .listar())
                .withRel("todos"));

        actualizado.add(linkTo(methodOn(PagoController.class)
                .eliminar(id))
                .withRel("delete"));

        return ResponseEntity.ok(actualizado);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        service.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}