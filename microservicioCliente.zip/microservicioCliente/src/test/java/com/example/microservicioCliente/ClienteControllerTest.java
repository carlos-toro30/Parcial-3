package com.example.microservicioCliente;

import com.example.microservicioCliente.controller.ClienteController;
import com.example.microservicioCliente.model.Cliente;
import com.example.microservicioCliente.service.ClienteService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ClienteControllerTest {
    @Mock
    private ClienteService service;

    @InjectMocks
    private ClienteController controller;

    @Test
    void deberiaCrearCliente() {

        Cliente cliente = new Cliente();
        cliente.setId(1L);

        when(service.crear(any(Cliente.class)))
                .thenReturn(cliente);

        ResponseEntity<Cliente> respuesta =
                controller.crear(cliente);

        assertEquals(HttpStatus.CREATED,
                respuesta.getStatusCode());

        assertNotNull(respuesta.getBody());

        assertEquals(1L,
                respuesta.getBody().getId());

        verify(service).crear(cliente);
    }

    @Test
    void deberiaListarClientes() {

        Cliente cliente = new Cliente();
        cliente.setId(1L);

        when(service.listar())
                .thenReturn(List.of(cliente));

        ResponseEntity<List<Cliente>> respuesta =
                controller.listar();

        assertEquals(HttpStatus.OK,
                respuesta.getStatusCode());

        assertEquals(1,
                respuesta.getBody().size());

        verify(service).listar();
    }

    @Test
    void deberiaObtenerClientePorId() {

        Cliente cliente = new Cliente();
        cliente.setId(1L);

        when(service.obtener(1L))
                .thenReturn(cliente);

        ResponseEntity<Cliente> respuesta =
                controller.obtener(1L);

        assertEquals(HttpStatus.OK,
                respuesta.getStatusCode());

        assertNotNull(respuesta.getBody());

        assertEquals(1L,
                respuesta.getBody().getId());

        verify(service).obtener(1L);
    }

    @Test
    void debeActualizarCliente() {

        Cliente cliente = new Cliente();
        cliente.setId(1L);
        cliente.setRut("12345678-9");
        cliente.setNombre("Juan");
        cliente.setApellido("Pérez");
        cliente.setCorreo("juan@gmail.com");
        cliente.setTelefono("987654321");
        cliente.setDireccion("Direccion nueva");

        when(service.actualizar(1L, cliente))
                .thenReturn(cliente);

        ResponseEntity<Cliente> response =
                controller.actualizar(1L, cliente);

        assertNotNull(response.getBody());
        assertEquals("Juan",
                response.getBody().getNombre());
        assertEquals("Pérez",
                response.getBody().getApellido());

        verify(service, times(1)).actualizar(1L, cliente);
    }
}
