package com.example.microservicioCliente;



import com.example.microservicioCliente.model.Cliente;
import com.example.microservicioCliente.repository.ClienteRepository;
import com.example.microservicioCliente.service.ClienteService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ClienteServiceTest {

    @Mock
    private ClienteRepository repository;

    @InjectMocks
    private ClienteService service;

    @Test
    void deberiaCrearCliente() {

        Cliente cliente = new Cliente();
        cliente.setId(1L);

        when(repository.save(any(Cliente.class)))
                .thenReturn(cliente);

        Cliente resultado = service.crear(cliente);

        assertNotNull(resultado);
        assertEquals(1L, resultado.getId());

        verify(repository).save(cliente);
    }

    @Test
    void deberiaListarClientes() {

        Cliente cliente = new Cliente();
        cliente.setId(1L);

        when(repository.findAll())
                .thenReturn(List.of(cliente));

        List<Cliente> resultado = service.listar();

        assertEquals(1, resultado.size());

        verify(repository).findAll();
    }

    @Test
    void deberiaObtenerClientePorId() {

        Cliente cliente = new Cliente();
        cliente.setId(1L);

        when(repository.findById(1L))
                .thenReturn(Optional.of(cliente));

        Cliente resultado = service.obtener(1L);

        assertEquals(1L, resultado.getId());

        verify(repository).findById(1L);
    }

    @Test
    void deberiaLanzarExcepcionSiClienteNoExiste() {

        when(repository.findById(1L))
                .thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(
                RuntimeException.class,
                () -> service.obtener(1L)
        );

        assertEquals("Cliente no encontrado",
                exception.getMessage());
    }

    @Test
    void deberiaEliminarCliente() {

        service.eliminar(1L);

        verify(repository).deleteById(1L);
    }

    @Test
    void debeActualizarCliente() {

        Cliente existente = new Cliente();
        existente.setId(1L);
        existente.setRut("12345678-9");
        existente.setNombre("Juan");
        existente.setApellido("Pérez");
        existente.setCorreo("juan@gmail.com");
        existente.setTelefono("111111111");
        existente.setDireccion("Dirección antigua");

        Cliente cliente = new Cliente();
        cliente.setRut("12345678-9");
        cliente.setNombre("Juan");
        cliente.setApellido("Pérez");
        cliente.setCorreo("juan@gmail.com");
        cliente.setTelefono("987654321");
        cliente.setDireccion("Dirección nueva");

        when(repository.findById(1L))
                .thenReturn(Optional.of(existente));

        when(repository.save(any(Cliente.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        Cliente resultado = service.actualizar(1L, cliente);

        assertNotNull(resultado);
        assertEquals("Juan", resultado.getNombre());
        assertEquals("Pérez", resultado.getApellido());
        assertEquals("12345678-9", resultado.getRut());
        assertEquals("juan@gmail.com", resultado.getCorreo());
        assertEquals("987654321", resultado.getTelefono());
        assertEquals("Dirección nueva", resultado.getDireccion());

        verify(repository, times(1)).findById(1L);
        verify(repository, times(1)).save(existente);
    }
}
