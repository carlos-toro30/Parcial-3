package com.example.microservicioCliente.controller;

import com.example.microservicioCliente.model.Cliente;
import com.example.microservicioCliente.service.ClienteService;


import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("/clientes")
@RequiredArgsConstructor
public class ClienteController {

    private final ClienteService service;

    @PostMapping
    public ResponseEntity<Cliente> crear(@Valid @RequestBody Cliente
                                                 cliente) {
        Cliente cli = service.crear(cliente);
        cli.add(linkTo(methodOn(ClienteController.class).listar()).withRel
                ("todos"));
        cli.add(linkTo(methodOn(ClienteController.class).obtener(cli.getId()
                )).withSelfRel());
        cli.add(linkTo(methodOn(ClienteController.class).actualizar(cli.getId(),cliente)).withRel("update"));
        cli.add(linkTo(methodOn(ClienteController.class).eliminar(cli.getId())).withRel("delete"));
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(cli);
    }

    @GetMapping
    public ResponseEntity<List<Cliente>> listar() {
        List<Cliente> lista = service.listar();

        lista.forEach(v -> {
            v.add(linkTo(methodOn(ClienteController.class)
                    .obtener(v.getId()))
                    .withSelfRel());

            v.add(linkTo(methodOn(ClienteController.class)
                    .actualizar(v.getId(), null))
                    .withRel("update"));

            v.add(linkTo(methodOn(ClienteController.class)
                    .eliminar(v.getId()))
                    .withRel("delete"));
        });

        return ResponseEntity.ok(lista);
    }



    @GetMapping("/{id}")
    public ResponseEntity<Cliente> obtener(@PathVariable Long id) {

        Cliente vehiculo = service.obtener(id);

        vehiculo.add(linkTo(methodOn(ClienteController.class)
                .obtener(id))
                .withSelfRel());

        vehiculo.add(linkTo(methodOn(ClienteController.class)
                .listar())
                .withRel("todos"));

        vehiculo.add(linkTo(methodOn(ClienteController.class)
                .actualizar(id, null))
                .withRel("update"));

        vehiculo.add(linkTo(methodOn(ClienteController.class)
                .eliminar(id))
                .withRel("delete"));

        return ResponseEntity.ok(vehiculo);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Cliente> actualizar(
            @PathVariable Long id,
            @RequestBody Cliente cliente) {

        Cliente actualizado = service.actualizar(id, cliente);

        actualizado.add(linkTo(methodOn(ClienteController.class)
                .obtener(id))
                .withSelfRel());

        actualizado.add(linkTo(methodOn(ClienteController.class)
                .listar())
                .withRel("todos"));

        actualizado.add(linkTo(methodOn(ClienteController.class)
                .eliminar(id))
                .withRel("delete"));

        return ResponseEntity.ok(actualizado);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        service.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
