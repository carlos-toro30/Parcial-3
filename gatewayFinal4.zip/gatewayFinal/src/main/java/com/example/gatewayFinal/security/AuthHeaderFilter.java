package com.example.gatewayFinal.security;

import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

@Component
public class AuthHeaderFilter implements GlobalFilter {

    @Override
    public Mono<Void> filter(org.springframework.web.server.ServerWebExchange exchange,
                             org.springframework.cloud.gateway.filter.GatewayFilterChain chain) {

        String authHeader = exchange.getRequest()
                .getHeaders()
                .getFirst("Authorization");

        if (authHeader != null) {
            exchange = exchange.mutate()
                    .request(exchange.getRequest()
                        .mutate()
                        .header("Authorization", authHeader)
                        .build())
                    .build();
        }

        return chain.filter(exchange);
    }
}